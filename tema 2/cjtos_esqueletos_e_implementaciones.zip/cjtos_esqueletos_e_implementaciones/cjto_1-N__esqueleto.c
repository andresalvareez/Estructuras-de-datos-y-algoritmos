/* Curso EDA 2020-2021
   Autor: Javier S�nchez Soriano
   TAD: Conjuntos 1..N

   TO-DO: Implementaci�n de los m�todos y main pendiente
*/


#include <stdio.h>
#include <string.h>

#define CORRECTO 0
#define ERR_INTRODUCIR 1
#define ERR_ELIMINAR 2
#define N 50



/* ZONA DE DECLARACI�N DE TIPOS*/

typedef enum {FALSE, TRUE} tBoolean;
typedef tBoolean tConjunto[N];


/* Prototipos de las funciones */
void cjtoVacio (tConjunto *C);
void initCjto (tConjunto *C, int elemento);
tBoolean esVacio (tConjunto C);

tBoolean  esta (tConjunto C, int elemento);
int aniadir (tConjunto *C, int elemento);
int quitar (tConjunto *C, int elemento);

void imprimeCjto (tConjunto C);
int cardinal (tConjunto C);

// Faltarian: union, interseccion y diferencia

int main() {
     //tConjunto Conjunto;

     //Conjunto[3] = FALSE;
     /* Este tipo de operaciones no deben hacerse con el TAD, lo suyo es usar las
     funciones que describen sus operaciones. Precisamente mediante la POO se logra
     encapsular los datos (atributos) evitando que esto se puede hacer.*/

     printf("Pendiente...\n");
}


void cjtoVacio (tConjunto *C){

}
void initCjto (tConjunto *C, int elemento) {

}

tBoolean esVacio (tConjunto C) {
    return TRUE;
}

tBoolean  esta (tConjunto C, int elemento) {
    return FALSE;
}

int aniadir (tConjunto *C, int elemento) {
    return ERR_INTRODUCIR;
}

int quitar (tConjunto *C, int elemento){
    return ERR_ELIMINAR;
}

void imprimeCjto (tConjunto C) {

}

int cardinal (tConjunto C){
    return 0;
}
