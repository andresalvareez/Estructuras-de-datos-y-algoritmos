/* Curso EDA 2020-2021
   Autor: Javier S�nchez Soriano
   TAD: Conjuntos 1..N ( 0..N-1 es lo que implementamos)
*/

#include <stdio.h>
#include <string.h>

#define CORRECTO 0
#define ERR_INTRODUCIR 1
#define ERR_ELIMINAR 2
#define N 50

/* ZONA DE DECLARACI�N DE TIPOS*/

typedef enum {FALSE, TRUE} tBoolean;    // Enumerado que simula booleanos
typedef tBoolean tConjunto[N];          // tConjunto: Array de N booleanos


/* Prototipos de las funciones */
void cjtoVacio (tConjunto C);
void initCjto (tConjunto C, int elemento);
tBoolean esVacio (tConjunto C);

tBoolean  esta (tConjunto C, int elemento);
int aniadir (tConjunto C, int elemento);
int quitar (tConjunto C, int elemento);

void imprimeCjto (tConjunto C);
int cardinal (tConjunto C);

// TO-DO: Faltarian union(), interseccion() y diferencia()...


int main() {
    // Creamos el conjunto
    printf("Se crea un conjunto vacio...\n");
    tConjunto conjunto;
    //cjtoVacio(conjunto);
    //initCjto(conjunto, 4);

    // Se crea conjunto con un elemento dentro...
    printf("Se crea un conjunto con el elemento 8 dentro...\n");
    initCjto(conjunto, 8);

    // cardinal?
    printf("cardinal: %d \n", cardinal(conjunto));
    // Es vac�o
    printf("esVacio: %d \n", esVacio(conjunto));

    // est�n el 8 y el 5?
    printf("Esta el 8? %d \n", esta(conjunto, 8));
    printf("Esta el 5? %d \n", esta(conjunto, 5));

    printf("Se a�aden unos elementos al conjunto...\n");
    aniadir(conjunto, 14);
    aniadir(conjunto, 14);  // Valor repetido
    aniadir(conjunto, 7);
    aniadir(conjunto, -5);  // NO valido

    imprimeCjto (conjunto);
    printf("cardinal: %d \n", cardinal(conjunto));

    printf("Se eliminan unos elementos al conjunto...\n");
    quitar(conjunto, 7);
    quitar(conjunto, -17);  // No valido

    imprimeCjto (conjunto);
    printf("cardinal: %d \n", cardinal(conjunto));
}

// Crea un conjunto vac�o. Si ya exist�a, borra los elementos
void cjtoVacio (tConjunto C){
    int i =0;
    for (i=0; i<N; i++) {
        C[i] = FALSE;
    }
}

void initCjto (tConjunto C, int elemento) {
    cjtoVacio(C);
    C[elemento]=TRUE;
}

tBoolean esVacio (tConjunto C) {
    tBoolean vacio = TRUE;

    // Funciona pero no es �ptimo. Lo suyo ser�a un while.
    if (cardinal(C)!= 0) {
        vacio = FALSE;
    }
    return vacio;
}

tBoolean  esta (tConjunto C, int elemento) {
    return C[elemento];
}

int aniadir (tConjunto C, int elemento) {
    int resultado = ERR_INTRODUCIR;
    if ((elemento>= 0) && (elemento <N)) {
       C[elemento]= TRUE;
       resultado = CORRECTO;
    }else {
        printf("ERROR AL ANIADIR el elemento: %d \n", elemento);
    }
    return resultado;
}

int quitar (tConjunto C, int elemento){
    int resultado = ERR_ELIMINAR;
    if ((elemento>= 0) && (elemento <N)) {
       C[elemento]= FALSE;
       resultado = CORRECTO;
    }
    else {
        printf("ERROR AL QUITAR el elemento %d, fuera de rango. \n", elemento);
    }
    return resultado;
}

void imprimeCjto (tConjunto C) {
    printf("\n------------------- \n");
    for (int i=0; i<N; i++) {
        if (C[i] /*==TRUE*/) {
            printf("  %d", i);
        }
    }
    printf("\n------------------- \n");
}

int cardinal (tConjunto C){
    int cardinal =0;
    for (int i=0; i<N; i++) {
        if (C[i] /*==TRUE*/) {
            cardinal++;
        }
    }
    return cardinal;
}
