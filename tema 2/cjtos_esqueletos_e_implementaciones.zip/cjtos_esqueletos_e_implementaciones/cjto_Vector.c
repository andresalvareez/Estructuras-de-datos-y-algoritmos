/* Curso EDA 2020-2021
   Autor: Javier S�nchez Soriano
   TAD: Conjuntos mediante el uso de Vectores

   TO-DO: Pendiente implementaci�n de los m�todos y main
*/


#include <stdio.h>
#include <string.h>

#define CORRECTO 0
#define ERR_INTRODUCIR 1
#define ERR_ELIMINAR 2
#define N 4



/* ZONA DE DECLARACI�N DE TIPOS*/

typedef enum {FALSE, TRUE} tBoolean;

typedef struct {
    int Elementos[N];
    int Ultimo;
} tConjunto;

void cjtoVacio (tConjunto *C);
void initCjto (tConjunto *C, int elemento);
tBoolean esVacio (tConjunto C);

tBoolean  esta (tConjunto C, int elemento);
int aniadir (tConjunto *C, int elemento);
int quitar (tConjunto *C, int elemento);

void imprimeCjto (tConjunto C);
int cardinal (tConjunto C);

// TO-DO: Faltarian union(), interseccion() y diferencia()...

int main() {

    tConjunto cjto; // Creaci�n de una variable estruct tConjunto (reserva de memoria impl�cita)
    tConjunto *conjunto = &cjto;    // Puntero a dicha estructura

     // Se crea conjunto vac�o
     printf("Se crea un conjunto vacio...\n");
     cjtoVacio(conjunto);
     printf("Es vacio: %d\n", esVacio(*conjunto));

     // Se crea conjunto con un elemento dentro...
      printf("\nSe crea un conjunto con el elemento 34 dentro...\n");
     initCjto(conjunto, 34);
     printf("Es vacio: %d\n", esVacio(*conjunto));


     imprimeCjto(*conjunto);
     printf("Cardinal: %d\n", cardinal(*conjunto));

     // Miramos si esta el elemento...
     printf("\nEsta 34? %d\n", esta(*conjunto, 34));
     printf("\nEsta 35? %d\n", esta(*conjunto, 35));

     printf("Se a�aden unos elementos al conjunto...\n");
     aniadir(conjunto, 4);
     aniadir(conjunto, 34); // Ya estaba
     aniadir(conjunto, -34);
     aniadir(conjunto, 8);
     aniadir(conjunto, 12); // No cabe para N=4
     imprimeCjto(*conjunto);
     printf("Cardinal: %d\n", cardinal(*conjunto));

     printf("Se eliminan unos elementos al conjunto...\n");
     quitar(conjunto, 34);  // Si est�
     quitar(conjunto, 77);  // no esta
     imprimeCjto(*conjunto);
     printf("\nCardinal: %d\n", cardinal(*conjunto));
}

void cjtoVacio (tConjunto *C){
    C->Ultimo=-1;
}

void initCjto (tConjunto *C, int elemento) {
    C->Ultimo = 0;
    C->Elementos[C->Ultimo] = elemento;
}

tBoolean esVacio (tConjunto C) {
    tBoolean vacio = FALSE;
    if (C.Ultimo == -1) {
        vacio = TRUE;
    }
    return vacio;
}

tBoolean  esta (tConjunto C, int elemento) {
    tBoolean presente = FALSE;
    int i = 0;

    while( (i<=C.Ultimo) && !presente) {
        if (C.Elementos[i] == elemento) {
            presente = TRUE;
        }
        i++;
    }
    return presente;
}

int aniadir (tConjunto *C, int elemento) {
    tBoolean resultado = ERR_INTRODUCIR;

    if (!esta(*C, elemento)) { // NO esta
        if (C->Ultimo<N-1 ) { // Si me cabe
            C->Ultimo++;
            C->Elementos[C->Ultimo] = elemento;
            resultado = CORRECTO;
        }
        else { //NO me cabe
            printf("ERROR. El elemento %d no estaba dentro pero NO CABE.\n", elemento);
        }
    }
    else { // SI esta
        resultado = CORRECTO;
        printf("El elemento %d YA estaba dentro del conjunto.\n", elemento);
    }
    return resultado;
}

int quitar (tConjunto *C, int elemento){
    tBoolean resultado = ERR_ELIMINAR;
    tBoolean presente = FALSE;  //
    int i = 0;                  //

    if (esVacio(*C)) { // Est� vac�o
        printf("ERROR. El conjunto esta vacio, no se puede eliminar.\n");
    }
    else { // No esta vac�o
        while( (i<=C->Ultimo) && !presente) {
            if (C->Elementos[i] == elemento) {
                presente = TRUE;
            }
            i++;
        }

        // Puede estar o no
        if (!presente) {
            printf("ERROR. El elemento %d no esta presente, no se puede eliminar.\n", elemento);
        }
        else { // est� y adem�s se encuentra en la posici�n i-1
            for (i=i; i<=C->Ultimo; i++) {
                C->Elementos[i-1] = C->Elementos[i];
            }
            C->Ultimo--;
            resultado = CORRECTO;
            printf("CORRECTO. Se elimina el elemento %d del conjunto.\n", elemento);
        }
    }

    return resultado;
}

void imprimeCjto (tConjunto C) {
    printf("\n------------------- \n");
    for (int i=0; i<=C.Ultimo; i++) {
        printf("  %d", C.Elementos[i]);
    }
    printf("\n------------------- \n");
}

int cardinal (tConjunto C){
    return C.Ultimo+1;
}
